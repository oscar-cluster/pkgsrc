#!/bin/sh -f
# 
#
#___INFO__MARK_BEGIN__
##########################################################################
#
#  The Contents of this file are made available subject to the terms of
#  the Sun Industry Standards Source License Version 1.2
#
#  Sun Microsystems Inc., March, 2001
#
#
#  Sun Industry Standards Source License Version 1.2
#  =================================================
#  The contents of this file are subject to the Sun Industry Standards
#  Source License Version 1.2 (the "License"); You may not use this file
#  except in compliance with the License. You may obtain a copy of the
#  License at http://gridengine.sunsource.net/Gridengine_SISSL_license.html
#
#  Software provided under this License is provided on an "AS IS" basis,
#  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
#  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
#  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
#  See the License for the specific provisions governing your rights and
#  obligations concerning the Software.
#
#  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
#
#  Copyright: 2001 by Sun Microsystems, Inc.
#
#  All Rights Reserved.
#
##########################################################################
#___INFO__MARK_END__

# stop of PVM conforming with Grid Engine
# parallel environment interface
#
# usage: stoppvm.sh [options] <pe_hostfile> <master_host>
#
#        options are:
#                     -catch_rsh
#                      Tells the shutdown procedure to look into the
#                      SGE created $TMPDIR to get the information about
#                      the used PVM machine.


use_kill=false

#
# shutdown of PVM conforming with Grid Engine
# parallel environment interface
#

#
# we clean up pvm files and kill pvmd's
#

# useful to control parameters passed to us
echo $*
me=`basename $0`

catch_rsh=0
while [ $# -gt 0 ]; do
   case "$1" in
      -catch_rsh)
         catch_rsh=1
         ;;
      *)
         break;
         ;;
   esac
   shift
done

rm $TMPDIR/hostfile

sge_pvm="$SGE_ROOT/pe/pvm"

# set the correct directory,
# to get the correct PVM instance.
if [ $catch_rsh = 1 ]; then
   export PVM_TMP=$TMPDIR

   rshcmd=rsh
   case "$ARC" in
      hp|hp10|hp11|hp11-64) rshcmd=remsh ;;
      *) ;;
   esac
   rm $TMPDIR/$rshcmd
fi

# PVM 3.4.4 knows a Virtual Machine IDs for supporting
# overlapping PVM instances of the same user
# PVM_VMID=$JOB_ID; export PVM_VMID
#
# annotation: if you want to use PVM_VMID in
# addition to the tight integration, be sure to
# set this also in your job's script (besides the
# necessary PVM_TMP).

if [ $use_kill = true ]; then

   pe_hostfile=$1
   host=$2

   echo "$me: cleanup on local host: $host"
   rm -rf /tmp/pvm[ld].*

   pids=`ps -awux | grep pvmd3 |grep -v grep | sed -e "s/[ ][ ]*/:/g" | cut -f2 -d:`
   for p in $pids; do
      echo "$me: killing pvmd with pid $p"
      kill $p
   done  

   RSH="ssh -x"
   for f in `cut -f1 -d" " $pe_hostfile`; do
      if [ ! $f = $host ]; then
         echo "$me: cleanup on host: $f"
         $RSH $f 'rm -rf /tmp/pvm[ld].*'
         pids=`$RSH $f 'ps -awux | grep pvmd3 |grep -v grep | sed -e "s/[ ][ ]*/:/g" | cut -f2 -d:'`
         for p in $pids; do
            echo "$me: killing pvmd with pid $p"
            $RSH $f "kill $p"
         done  
      fi
   done
else
   if [ ! -x $sge_pvm/bin/$ARC/stop_pvm ]; then
      echo "$me: can't execute $sge_pvm/bin/$ARC/stop_pvm" >&2
      exit 1
   fi
   $sge_pvm/bin/$ARC/stop_pvm
fi

exit 0
