/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 9
#define PATCHLEVEL 0
#define DATE "1999-08-16"

#endif /* _h_patchlevel */
