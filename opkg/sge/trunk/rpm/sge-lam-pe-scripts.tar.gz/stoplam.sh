#!/bin/sh
#
#
# (c) 2002 Sun Microsystems, Inc. Use is subject to license terms.  

#
# shutdown of LAM conforming with the Grid Engine
# Parallel Environment interface
#
# Just remove machine-file that was written by startmpi.sh
#
rm $TMPDIR/machines

rshcmd=rsh
case "$ARC" in
   hp|hp10|hp11|hp11-64) rshcmd=remsh ;;
   *) ;;
esac
rm $TMPDIR/$rshcmd 2>/dev/null

#
# Extra LAM statement(s)
#
if [ -z "`which lamboot 2>/dev/null`" ] ; then
    export PATH=/home/reuti/local/lam-7.1.1/bin:$PATH
fi
lamhalt

exit 0
